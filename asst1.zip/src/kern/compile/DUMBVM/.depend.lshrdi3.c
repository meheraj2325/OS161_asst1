lshrdi3.o: ../../../common/gcc-millicode/lshrdi3.c \
 ../../../common/gcc-millicode/longlong.h ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/endian.h \
 ../../include/kern/endian.h includelinks/kern/machine/endian.h \
 ../../include/limits.h ../../include/kern/limits.h
